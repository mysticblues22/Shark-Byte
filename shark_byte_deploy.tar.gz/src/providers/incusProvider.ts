import { exec } from "child_process";
import { promisify } from "util";
import {
  HostCapacity,
  LxcContainerInfo,
  LxcContainerState,
  LxcProvisionRequest,
  LxcProvisionResult,
  VpsProvider,
} from "./types";
import { SshClient } from "./sshClient";

const execPromise = promisify(exec);

const SAFE_CONTAINER_NAME = /^[a-z0-9][a-z0-9-]{0,62}$/;
const SAFE_HOSTNAME = /^[a-zA-Z0-9.-]{1,253}$/;

function containerNameFor(vpsNumber: number): string {
  if (!Number.isInteger(vpsNumber) || vpsNumber < 1) {
    throw new Error("VPS number must be a positive integer.");
  }
  return `shark-vps-${String(vpsNumber).padStart(6, "0")}`;
}

function assertSafeContainerName(value: string): void {
  if (!SAFE_CONTAINER_NAME.test(value)) {
    throw new Error(`Unsafe container name: ${value}`);
  }
}

function assertSafeHostname(value: string): void {
  if (!SAFE_HOSTNAME.test(value)) {
    throw new Error(`Unsafe hostname: ${value}`);
  }
}

function bytesFromGb(gb: number): number {
  return Math.floor(gb * 1024 * 1024 * 1024);
}

function parseKeyValueOutput(output: string): Map<string, string> {
  const values = new Map<string, string>();
  for (const line of output.split(/\r?\n/)) {
    const separator = line.indexOf("=");
    if (separator === -1) continue;
    const key = line.slice(0, separator).trim();
    const value = line.slice(separator + 1).trim();
    values.set(key, value);
  }
  return values;
}

export class IncusProvider implements VpsProvider {
  private readonly ssh?: SshClient;
  private readonly imageAlias: string;
  private readonly storagePool: string;
  private readonly storagePoolType: string;
  private readonly requireHardQuota: boolean;
  private readonly processLimit: string;

  public constructor(ssh?: SshClient) {
    this.ssh = ssh;
    this.imageAlias = process.env.VPS_INCUS_IMAGE_ALIAS?.trim() || "24.04";
    this.storagePool = process.env.VPS_INCUS_STORAGE_POOL?.trim() || "default";
    this.storagePoolType = process.env.VPS_INCUS_STORAGE_POOL_TYPE?.trim().toLowerCase() || "dir";
    this.requireHardQuota = (process.env.VPS_INCUS_REQUIRE_HARD_QUOTA?.trim() ?? "false") === "true";
    this.processLimit = process.env.VPS_INCUS_LIMIT_PROCESSES?.trim() || "512";
  }

  private async runCommand(cmd: string, timeoutMs: number = 60000): Promise<{ stdout: string; stderr: string; exitCode: number }> {
    const host = process.env.VPS_NODE_HOST?.trim();
    const isLocal = !host || host === "127.0.0.1" || host === "localhost" || host === "local" || !this.ssh;

    if (isLocal || !this.ssh) {
      try {
        const { stdout, stderr } = await execPromise(cmd, {
          maxBuffer: 10 * 1024 * 1024,
          timeout: timeoutMs,
          killSignal: "SIGKILL",
        });
        return { stdout, stderr, exitCode: 0 };
      } catch (err: any) {
        if (err.killed || err.signal === "SIGKILL") {
          return {
            stdout: err.stdout || "",
            stderr: `Command execution timed out after ${timeoutMs}ms: ${cmd}`,
            exitCode: 124,
          };
        }
        return {
          stdout: err.stdout || "",
          stderr: err.stderr || err.message || "",
          exitCode: typeof err.code === "number" ? err.code : 1,
        };
      }
    }
    return this.ssh.run(cmd);
  }

  private async runCheckedCommand(cmd: string, timeoutMs: number = 60000): Promise<{ stdout: string; stderr: string; exitCode: number }> {
    const res = await this.runCommand(cmd, timeoutMs);
    if (res.exitCode !== 0) {
      throw new Error(`Command failed (exit ${res.exitCode}): ${cmd}\n${res.stderr || res.stdout}`);
    }
    return res;
  }

  private async runProvisionStage<T>(stage: string, operation: () => Promise<T>): Promise<T> {
    try {
      return await operation();
    } catch (error) {
      throw new Error(`Failed during Incus ${stage}: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  }

  public getContainerName(vpsNumber: number): string {
    return containerNameFor(vpsNumber);
  }

  public async validateImageAlias(imageAlias?: string): Promise<boolean> {
    const alias = imageAlias || this.imageAlias;
    const res = await this.runCommand(`incus image info ${alias}`, 10000);
    return res.exitCode === 0;
  }

  public async getHostCapacity(): Promise<HostCapacity> {
    const result = await this.runCheckedCommand(
      [
        "set -eu",
        'TOTAL_MEMORY="$(awk \'/MemTotal/ {print $2 * 1024}\' /proc/meminfo)"',
        'AVAILABLE_MEMORY="$(awk \'/MemAvailable/ {print $2 * 1024}\' /proc/meminfo)"',
        'CPU_COUNT="$(nproc)"',
        'ROOT_AVAILABLE="$(df -B1 / | awk \'NR==2 {print $4}\')"',
        'CONTAINER_COUNT="$(incus list --format csv 2>/dev/null | wc -l | tr -d \' \')"',
        'printf "totalMemoryBytes=%s\\n" "$TOTAL_MEMORY"',
        'printf "availableMemoryBytes=%s\\n" "$AVAILABLE_MEMORY"',
        'printf "cpuCount=%s\\n" "$CPU_COUNT"',
        'printf "rootFilesystemAvailableBytes=%s\\n" "$ROOT_AVAILABLE"',
        'printf "existingContainerCount=%s\\n" "$CONTAINER_COUNT"',
      ].join("\n")
    );

    const values = parseKeyValueOutput(result.stdout);

    return {
      totalMemoryBytes: Number(values.get("totalMemoryBytes") ?? 0),
      availableMemoryBytes: Number(values.get("availableMemoryBytes") ?? 0),
      cpuCount: Number(values.get("cpuCount") ?? 0),
      rootFilesystemAvailableBytes: Number(values.get("rootFilesystemAvailableBytes") ?? 0),
      existingContainerCount: Number(values.get("existingContainerCount") ?? 0),
    };
  }

  public async containerExists(containerName: string): Promise<boolean> {
    assertSafeContainerName(containerName);
    const result = await this.runCommand(`incus info ${containerName}`, 10000);
    return result.exitCode === 0;
  }

  public async getContainerInfo(containerName: string): Promise<LxcContainerInfo> {
    assertSafeContainerName(containerName);

    const result = await this.runCommand(`incus list ${containerName} --format json`, 10000);
    if (result.exitCode !== 0) {
      return { name: containerName, state: "UNKNOWN", privateIpv4: null };
    }

    try {
      const parsed = JSON.parse(result.stdout) as Array<{
        name: string;
        status: string;
        state?: {
          network?: Record<string, { addresses?: Array<{ family: string; address: string; scope: string }> }>;
        };
      }>;

      const instance = parsed.find((i) => i.name === containerName) || parsed[0];
      if (!instance) return { name: containerName, state: "UNKNOWN", privateIpv4: null };

      const statusUpper = (instance.status || "").toUpperCase();
      const state: LxcContainerState =
        statusUpper === "RUNNING" || statusUpper === "STOPPED" || statusUpper === "FROZEN"
          ? statusUpper
          : "UNKNOWN";

      let privateIpv4: string | null = null;
      if (instance.state?.network) {
        for (const netDevice of Object.values(instance.state.network)) {
          if (netDevice.addresses) {
            for (const addr of netDevice.addresses) {
              if (addr.family === "inet" && addr.scope === "global" && addr.address !== "127.0.0.1" && addr.address !== "0.0.0.0") {
                privateIpv4 = addr.address;
                break;
              }
            }
          }
          if (privateIpv4) break;
        }
      }

      return { name: containerName, state, privateIpv4 };
    } catch {
      return { name: containerName, state: "UNKNOWN", privateIpv4: null };
    }
  }

  private async waitForPrivateIpv4(containerName: string, timeoutSeconds: number = 30): Promise<string> {
    const startedAt = Date.now();
    const timeoutMs = timeoutSeconds * 1000;

    while (Date.now() - startedAt < timeoutMs) {
      const info = await this.getContainerInfo(containerName);
      if (info.state === "RUNNING" && info.privateIpv4 && info.privateIpv4 !== "0.0.0.0" && info.privateIpv4 !== "127.0.0.1") {
        return info.privateIpv4;
      }
      await new Promise((res) => setTimeout(res, 2000));
    }

    throw new Error(`Timed out waiting for DHCP IPv4 address assignment on Incus container ${containerName}.`);
  }

  private validateRequest(request: LxcProvisionRequest): void {
    const containerName = request.containerName?.trim() || containerNameFor(request.vpsNumber);
    assertSafeContainerName(containerName);
    assertSafeHostname(request.hostname);

    if (request.resources.ramGb <= 0 || !Number.isFinite(request.resources.ramGb)) {
      throw new Error("RAM must be greater than zero.");
    }
    if (!Number.isInteger(request.resources.vcpu) || request.resources.vcpu < 1) {
      throw new Error("vCPU must be a positive integer.");
    }
    if (request.resources.storageGb <= 0 || !Number.isFinite(request.resources.storageGb)) {
      throw new Error("Storage must be greater than zero.");
    }

    if (this.requireHardQuota && this.storagePoolType === "dir") {
      throw new Error(
        `Safety Check: Incus storage pool "${this.storagePool}" (type: dir) does not enforce hard per-VPS disk quotas.`
      );
    }
  }

  public async provision(
    request: LxcProvisionRequest,
    onProgress?: (statusText: string) => Promise<void>
  ): Promise<LxcProvisionResult> {
    this.validateRequest(request);
    const containerName = request.containerName?.trim() || containerNameFor(request.vpsNumber);

    const imageValid = await this.runProvisionStage("image validation", () =>
      this.validateImageAlias(this.imageAlias)
    );

    if (!imageValid) {
      throw new Error(`Configured Incus image alias "${this.imageAlias}" was not found or is unavailable.`);
    }

    const alreadyExists = await this.runProvisionStage("container existence check", () =>
      this.containerExists(containerName)
    );

    if (alreadyExists) {
      throw new Error(`Container ${containerName} already exists.`);
    }

    const capacity = await this.runProvisionStage("host capacity check", () =>
      this.getHostCapacity()
    );

    const requestedMemoryBytes = bytesFromGb(request.resources.ramGb);

    if (capacity.availableMemoryBytes < requestedMemoryBytes) {
      throw new Error(
        `Insufficient available host memory. Requested ${request.resources.ramGb} GB, available ${(capacity.availableMemoryBytes / 1024 / 1024 / 1024).toFixed(2)} GB.`
      );
    }

    if (capacity.rootFilesystemAvailableBytes < bytesFromGb(request.resources.storageGb)) {
      throw new Error(
        `Insufficient root filesystem capacity for requested ${request.resources.storageGb} GB.`
      );
    }

    let created = false;

    try {
      if (onProgress) {
        await onProgress("Step 1/5: Launching Incus LXC Container Workspace...").catch(() => {});
      }
      console.log(`🚀 [Incus] Launching container "${containerName}" with image "${this.imageAlias}"...`);

      const launchCmdWithDisk = `incus launch ${this.imageAlias} ${containerName} -p default -d root,size=${request.resources.storageGb}GiB -c limits.memory=${request.resources.ramGb}GiB -c limits.cpu=${request.resources.vcpu} -c limits.processes=${this.processLimit}`;
      const launchRes = await this.runCommand(launchCmdWithDisk, 90000);

      if (launchRes.exitCode === 0) {
        created = true;
      } else {
        console.warn(`⚠️ [Incus] Launch with inline disk quota failed, attempting fallback launch without inline disk option...`);
        const fallbackLaunchCmd = `incus launch ${this.imageAlias} ${containerName} -p default -c limits.memory=${request.resources.ramGb}GiB -c limits.cpu=${request.resources.vcpu} -c limits.processes=${this.processLimit}`;
        await this.runProvisionStage("container launch fallback", () => this.runCheckedCommand(fallbackLaunchCmd, 90000));
        created = true;
        await this.runCommand(`incus config device set ${containerName} root size=${request.resources.storageGb}GiB`, 10000).catch(() => {});
      }

      console.log(`✅ [Incus] Container "${containerName}" created successfully.`);

      if (request.enableNesting) {
        console.log(`⚙️ [Incus] Enabling nesting for "${containerName}"...`);
        await this.runCheckedCommand(`incus config set ${containerName} security.nesting true`, 10000).catch(() => {});
      }

      if (request.publicSshPort) {
        if (onProgress) {
          await onProgress(`Step 2/5: Configuring Incus Host SSH Proxy Device (Port ${request.publicSshPort} -> 22)...`).catch(() => {});
        }
        console.log(`🔌 [Incus] Adding SSH proxy device (port ${request.publicSshPort} -> 22) for "${containerName}"...`);
        const proxyCmd = `incus config device add ${containerName} proxy-ssh-${request.publicSshPort} proxy listen=tcp:0.0.0.0:${request.publicSshPort} connect=tcp:127.0.0.1:22`;
        await this.runProvisionStage("SSH proxy port forwarding", () => this.runCheckedCommand(proxyCmd, 15000));

        const deviceCheck = await this.runCommand(`incus config device show ${containerName}`, 10000);
        if (!deviceCheck.stdout.includes(`proxy-ssh-${request.publicSshPort}`)) {
          throw new Error(`Failed to verify Incus proxy device proxy-ssh-${request.publicSshPort} on ${containerName}.`);
        }
      }

      if (request.initialPassword) {
        if (onProgress) {
          await onProgress("Step 3/5: Configuring Container SSH Server & Setting Root Password...").catch(() => {});
        }
        console.log(`🔑 [Incus] Configuring SSH server and root password for "${containerName}"...`);
        const encodedPassword = Buffer.from(request.initialPassword, "utf8").toString("base64");
        const passCmd = `incus exec ${containerName} -- sh -lc 'mkdir -p /run/sshd /etc/ssh/sshd_config.d; printf "PermitRootLogin yes\\nPasswordAuthentication yes\\n" > /etc/ssh/sshd_config.d/99-shark.conf; grep -q "^Include /etc/ssh/sshd_config.d/\\*.conf" /etc/ssh/sshd_config || printf "\\nInclude /etc/ssh/sshd_config.d/*.conf\\n" >> /etc/ssh/sshd_config; killall -HUP sshd 2>/dev/null || true; echo root:$(printf %s ${encodedPassword} | base64 -d) | chpasswd'`;
        await this.runProvisionStage("SSH/password setup", () => this.runCheckedCommand(passCmd, 30000));
        console.log(`✅ [Incus] SSH credentials and root password applied to "${containerName}".`);
      }

      if (onProgress) {
        await onProgress("Step 4/5: Waiting for Container DHCP Private IPv4 Discovery...").catch(() => {});
      }
      console.log(`🌐 [Incus] Fetching DHCP private IPv4 address on "${containerName}"...`);
      const discoveredIp = await this.waitForPrivateIpv4(containerName, 30);
      const privateIpv4 = request.staticPrivateIpv4 || discoveredIp;
      console.log(`📡 [Incus] Discovered valid IP "${privateIpv4}" for "${containerName}".`);

      if (onProgress) {
        await onProgress("Step 5/5: Verifying Container State & Health Check...").catch(() => {});
      }
      const finalInfo = await this.runProvisionStage("final verification", () =>
        this.getContainerInfo(containerName)
      );

      if (finalInfo.state !== "RUNNING") {
        throw new Error(`Incus container ${containerName} did not remain RUNNING.`);
      }

      const sshServiceCheck = await this.runCommand(
        `incus exec ${containerName} -- sh -c 'systemctl is-active ssh 2>/dev/null || systemctl is-active sshd 2>/dev/null || ss -lntp | grep :22'`,
        10000
      );
      if (sshServiceCheck.exitCode !== 0) {
        console.warn(`⚠️ SSH service inside ${containerName} returned non-zero status, attempting to start SSH service...`);
        await this.runCommand(`incus exec ${containerName} -- sh -c 'systemctl start ssh || service ssh start'`, 15000).catch(() => {});
      }

      console.log(`🎉 [Incus] Provisioning complete for "${containerName}"!`);
      const storageEnforced = this.storagePoolType !== "dir";
      return {
        containerName,
        hostname: request.hostname,
        state: finalInfo.state,
        privateIpv4,
        requestedRamGb: request.resources.ramGb,
        requestedVcpu: request.resources.vcpu,
        requestedStorageGb: request.resources.storageGb,
        ramLimitApplied: true,
        cpuLimitApplied: true,
        storageLimitApplied: true,
        storageLimitEnforced: storageEnforced,
        storageBackend: this.storagePoolType,
        storageStatus: storageEnforced ? "enforced_block_quota" : "unbounded_directory",
        storageLimitMessage: storageEnforced ? "Quota applied" : "Directory storage pool",
        createdAt: new Date(),
      };
    } catch (error) {
      console.error(`❌ [Incus] Error provisioning "${containerName}":`, error);
      if (created) {
        console.log(`🧹 [Incus] Cleaning up failed container "${containerName}"...`);
        await this.runCommand(`incus delete -f ${containerName}`, 30000).catch((err) => {
          console.error(`⚠️ Failed to clean up container ${containerName}:`, err);
        });
      }
      throw error;
    }
  }

  public async setNesting(containerName: string, enable: boolean): Promise<void> {
    assertSafeContainerName(containerName);
    await this.runCheckedCommand(`incus config set ${containerName} security.nesting ${enable ? "true" : "false"}`);
  }

  public async isNestingEnabled(containerName: string): Promise<boolean> {
    assertSafeContainerName(containerName);
    const res = await this.runCommand(`incus config get ${containerName} security.nesting`);
    return res.stdout.trim() === "true";
  }

  public async start(containerName: string): Promise<LxcContainerInfo> {
    assertSafeContainerName(containerName);
    await this.runCheckedCommand(`incus start ${containerName}`);
    return this.getContainerInfo(containerName);
  }

  public async stop(containerName: string): Promise<LxcContainerInfo> {
    assertSafeContainerName(containerName);
    await this.runCheckedCommand(`incus stop ${containerName}`);
    return this.getContainerInfo(containerName);
  }

  public async restart(containerName: string): Promise<LxcContainerInfo> {
    assertSafeContainerName(containerName);
    await this.runCheckedCommand(`incus restart ${containerName}`);
    return this.getContainerInfo(containerName);
  }

  public async destroy(containerName: string): Promise<void> {
    assertSafeContainerName(containerName);
    await this.runCheckedCommand(`incus delete -f ${containerName}`);
  }

  public async runInContainer(containerName: string, command: string): Promise<string> {
    assertSafeContainerName(containerName);
    const res = await this.runCheckedCommand(`incus exec ${containerName} -- ${command}`);
    return res.stdout;
  }

  public async getDiagnostics(): Promise<any> {
    const incusVer = await this.runCommand("incus version", 5000).then((r) => r.stdout.trim()).catch(() => "Unavailable");
    const profileCheck = await this.runCommand("incus profile show default", 5000).then((r) => r.exitCode === 0).catch(() => false);
    const imageCheck = await this.validateImageAlias(this.imageAlias).catch(() => false);
    const networkCheck = await this.runCommand("incus network list", 5000).then((r) => r.stdout).catch(() => "Unavailable");
    const capacity = await this.getHostCapacity().catch(() => null);

    return {
      incusVersion: incusVer,
      defaultProfileExists: profileCheck,
      configuredImageAlias: this.imageAlias,
      imageAvailable: imageCheck,
      hostCapacity: capacity,
      networks: networkCheck,
    };
  }
}
