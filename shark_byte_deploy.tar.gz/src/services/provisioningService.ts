import crypto from "crypto";
import { EmbedBuilder, Guild, GuildMember, TextChannel } from "discord.js";
import { getOrCreateCustomer, getTicketById } from "./ticketDatabase";
import { createVpsInstance, getVpsByTicketId } from "./vpsDatabase";
import { SshClient } from "../providers/sshClient";
import { IncusProvider } from "../providers/incusProvider";
import { PterodactylProvider } from "../providers/pterodactylProvider";
import { getPool } from "../config/database";
import { logBotError } from "./loggerService";

export function generateSecurePassword(length: number = 16): string {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
  let password = "";
  const bytes = crypto.randomBytes(length);
  for (let i = 0; i < length; i++) {
    password += chars[bytes[i] % chars.length];
  }
  return password;
}

export async function provisionVpsOrder(
  guild: Guild,
  ticketId: string,
  member: GuildMember,
  metadata: any,
  onProgress?: (stepText: string) => Promise<void>
): Promise<void> {
  const channel = guild.channels.cache.find(
    (c): c is TextChannel => c.type === 0 && Boolean(c.topic?.includes(`ticket-id:${ticketId}`))
  );

  const { getVpsByTicketId, updateVpsStatus, lockAndInitializeVpsProvisioning } = await import("./vpsDatabase");

  // Check if ticket already has a VPS record (concurrency & restart safety)
  const existingVps = await getVpsByTicketId(ticketId);
  if (existingVps) {
    if (existingVps.status === "active") {
      if (channel) {
        const embed = new EmbedBuilder()
          .setTitle("🚀 Shark Byte VPS Active (Already Provisioned)")
          .setColor(0x2ecc71)
          .setDescription(
            `This ticket already has an active provisioned VPS instance!\n\n` +
              `━━━━━━━━━━━━━━━━━━━━\n` +
              `🖥️ **INSTANCE DETAILS**\n` +
              `━━━━━━━━━━━━━━━━━━━━\n` +
              `• **VPS Number:** #${existingVps.vpsNumber}\n` +
              `• **Hostname:** \`${existingVps.hostname}\`\n` +
              `• **Container:** \`${existingVps.providerInstanceId}\`\n` +
              `• **Location:** ${existingVps.location}\n` +
              `• **Status:** 🟢 \`ACTIVE\`\n\n` +
              `━━━━━━━━━━━━━━━━━━━━\n` +
              `⚙️ **RESOURCES & HARDWARE**\n` +
              `━━━━━━━━━━━━━━━━━━━━\n` +
              `• **RAM:** ${existingVps.ramGb} GB\n` +
              `• **vCPU:** ${existingVps.vcpu} Core(s)\n` +
              `• **Storage:** ${existingVps.storageGb} GB NVMe\n` +
              `• **Private IP:** \`${existingVps.privateIpv4 || "N/A"}\`\n\n` +
              `━━━━━━━━━━━━━━━━━━━━\n` +
              `🔑 **SSH GATEWAY CREDENTIALS**\n` +
              `━━━━━━━━━━━━━━━━━━━━\n` +
              `• **SSH Command:** \`ssh -p ${existingVps.publicSshPort || 22100} root@${existingVps.publicSshHost || "ssh.mysticservers.com"}\` \n` +
              `• **SSH Port:** \`${existingVps.publicSshPort || 22100}\`\n` +
              `• **SSH Username:** \`root\`\n` +
              `• **Management Panel:** [https://nexora.mysticservers.com](https://nexora.mysticservers.com)`
          )
          .setFooter({ text: "Shark Byte • VPS Deployment Engine" })
          .setTimestamp();
        await channel.send({ content: `${member}`, embeds: [embed] });
      }
      return;
    }

    if (["allocating", "launching", "configuring", "networking", "ssh_configuring", "verifying"].includes(existingVps.status)) {
      throw new Error(`⌛ VPS provisioning is currently in progress for this ticket (Status: ${existingVps.status.toUpperCase()}). Please wait.`);
    }
  }

  const planName = (metadata.planName as string) || "STANDARD";
  const ramGb = Number(metadata.ramGb || 2);
  const vcpu = Number(metadata.vcpu || 1);
  const storageGb = Number(metadata.storageGb || 20);
  const priceInr = Number(metadata.priceInr || 199);
  const priceUsd = Number(metadata.priceUsd || 2.5);
  const location = (metadata.location as string) || "India 🇮🇳";

  // 1. Get or Create Customer Record
  const customer = await getOrCreateCustomer(
    member.user.id,
    member.user.username,
    member.displayName
  );

  // 2. Increment Customer VPS sequence
  const pool = getPool();
  const seqRes = await pool.query(
    `UPDATE customers SET vps_sequence_counter = vps_sequence_counter + 1 WHERE id = $1 RETURNING vps_sequence_counter`,
    [customer.id]
  );
  const vpsSequence = seqRes.rows[0]?.vps_sequence_counter || 1;

  const hostname = `vps-${String(vpsSequence).padStart(3, "0")}-${member.user.username.toLowerCase().replace(/[^a-z0-9]/g, "")}.sharkbyte.com`;
  const containerName = `shark-vps-${String(vpsSequence).padStart(6, "0")}`;
  const rootPassword = generateSecurePassword(16);

  // 3. Atomically lock ticket, allocate SSH port, and initialize DB record in state 'allocating'
  let vpsRecord = await lockAndInitializeVpsProvisioning({
    customerId: customer.id,
    ticketId,
    planName,
    location,
    priceInr,
    priceUsd,
    ramGb,
    vcpu,
    storageGb,
    providerInstanceId: containerName,
    hostname,
    customerVpsSequence: vpsSequence,
    sshUsername: "root",
    sshPort: 22,
    provisionedByDiscordId: member.user.id,
    billingCycleMonths: 1,
  });

  const publicSshHost = vpsRecord.publicSshHost || "ssh.mysticservers.com";
  const publicSshPort = vpsRecord.publicSshPort!;

  // 4. Attempt Incus / LXC Container Provisioning on VPS Host Node
  let provisionResult: any;

  try {
    const incus = new IncusProvider();
    provisionResult = await incus.provision(
      {
        vpsNumber: vpsSequence,
        containerName,
        hostname,
        resources: { ramGb, vcpu, storageGb },
        templateDistribution: process.env.VPS_LXC_TEMPLATE_DISTRIBUTION || "ubuntu",
        templateRelease: process.env.VPS_LXC_TEMPLATE_RELEASE || "jammy",
        templateArchitecture: process.env.VPS_LXC_TEMPLATE_ARCHITECTURE || "amd64",
        bridgeName: process.env.VPS_LXC_BRIDGE || "incusbr1",
        initialPassword: rootPassword,
        publicSshPort,
        enableNesting: false,
      },
      async (stepText) => {
        let currentStatus = "configuring";
        if (stepText.includes("Step 1/5")) currentStatus = "launching";
        else if (stepText.includes("Step 2/5")) currentStatus = "ssh_configuring";
        else if (stepText.includes("Step 3/5")) currentStatus = "configuring";
        else if (stepText.includes("Step 4/5")) currentStatus = "networking";
        else if (stepText.includes("Step 5/5")) currentStatus = "verifying";

        await updateVpsStatus(vpsRecord.id, currentStatus).catch(() => {});
        if (onProgress) {
          await onProgress(stepText).catch(() => {});
        }
      }
    );

    // 5. Update Database Record to ACTIVE on clean verification
    const updatedRecord = await updateVpsStatus(vpsRecord.id, "active", {
      privateIpv4: provisionResult.privateIpv4,
      publicSshPort,
    });
    if (updatedRecord) {
      vpsRecord = updatedRecord;
    }
  } catch (err: any) {
    console.error(`❌ Incus LXC Provisioning Error for ${containerName}:`, err);
    if (vpsRecord?.id) {
      await updateVpsStatus(vpsRecord.id, "failed").catch(() => {});
    }

    await logBotError({
      guild,
      error: err,
      title: "Incus LXC Container Provisioning Error",
      context: "provisionVpsOrder:incus",
      userTag: member.user.tag,
      userId: member.user.id,
      severity: "ERROR",
    }).catch(() => {});

    throw new Error(`Incus LXC container creation failed: ${err.message}`);
  }

  // 6. Send Provisioned Card to Ticket Channel
  if (channel) {
    const embed = new EmbedBuilder()
      .setTitle("🚀 Shark Byte VPS Provisioned & Active!")
      .setColor(0x2ecc71)
      .setDescription(
        `Your **${planName}** VPS has been successfully deployed and configured!\n\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `🖥️ **INSTANCE DETAILS**\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `• **VPS Number:** #${vpsRecord.vpsNumber}\n` +
          `• **Hostname:** \`${hostname}\`\n` +
          `• **Container:** \`${containerName}\`\n` +
          `• **Location:** ${location}\n` +
          `• **Status:** 🟢 \`ACTIVE\` (Incus LXC Container)\n\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `⚙️ **RESOURCES & HARDWARE**\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `• **RAM:** ${ramGb} GB\n` +
          `• **vCPU:** ${vcpu} Core(s)\n` +
          `• **Storage:** ${storageGb} GB NVMe\n` +
          `• **Private IP:** \`${provisionResult.privateIpv4}\`\n\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `🔑 **SSH GATEWAY CREDENTIALS**\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `• **SSH Command:** \`ssh -p ${publicSshPort} root@${publicSshHost}\` \n` +
          `• **SSH Port:** \`${publicSshPort}\`\n` +
          `• **SSH Username:** \`root\`\n` +
          `• **Root Password:** \`${rootPassword}\`\n` +
          `• **Management Panel:** [https://nexora.mysticservers.com](https://nexora.mysticservers.com)\n\n` +
          `⚠️ *Please change your root password immediately upon first login using \`passwd\` command.*`
      )
      .setFooter({ text: "Shark Byte • Automated VPS Deployment Engine" })
      .setTimestamp();

    await channel.send({ content: `${member}`, embeds: [embed] });
  }
}

export async function provisionMinecraftOrder(
  guild: Guild,
  ticketId: string,
  member: GuildMember,
  metadata: any
): Promise<void> {
  const channel = guild.channels.cache.find(
    (c): c is TextChannel => c.type === 0 && Boolean(c.topic?.includes(`ticket-id:${ticketId}`))
  );

  const planName = (metadata.planName as string) || "Starter Minecraft";
  const ramGb = Number(metadata.ramGb || 2);
  const ramMb = ramGb * 1024;
  const cpuPercent = Number(metadata.cpuPercent || 100);
  const storageGb = Number(metadata.storageGb || 10);
  const priceInr = Number(metadata.priceInr || 199);
  const priceUsd = Number(metadata.priceUsd || 2.5);

  const customer = await getOrCreateCustomer(
    member.user.id,
    member.user.username,
    member.displayName
  );

  const pool = getPool();
  const seqRes = await pool.query(
    `UPDATE customers SET minecraft_sequence_counter = minecraft_sequence_counter + 1 WHERE id = $1 RETURNING minecraft_sequence_counter`,
    [customer.id]
  );
  const mcSequence = seqRes.rows[0]?.minecraft_sequence_counter || 1;

  const serverName = `${planName} - ${member.displayName}`;
  let pteroUserId = customer.pterodactylUserId || 1;

  // Try Pterodactyl API user & server provisioning
  try {
    const ptero = new PterodactylProvider();
    if (!customer.pterodactylUserId) {
      const existing = await ptero.findUserByEmail(`${member.user.username}@sharkbyte.com`).catch(() => null);
      if (existing) {
        pteroUserId = existing.id;
      } else {
        const newUser = await ptero.createUser({
          username: `mc_${member.user.id.slice(-6)}`,
          email: `${member.user.id}@sharkbyte.com`,
          firstName: member.displayName.slice(0, 10),
          lastName: "Customer",
        }).catch(() => null);
        if (newUser) pteroUserId = newUser.id;
      }
    }
  } catch (err) {
    console.warn("⚠️ Pterodactyl API not configured or offline. Creating local server reservation.");
  }

  const port = 25565 + mcSequence;

  // Insert database record
  await pool.query(
    `
    INSERT INTO minecraft_servers (
      customer_id, ticket_id, pterodactyl_server_id, pterodactyl_identifier, pterodactyl_user_id,
      server_name, customer_minecraft_sequence, plan_id, plan_name, price_inr, price_usd,
      ram_mb, cpu_limit, storage_mb, allocation_id, allocation_ip, allocation_port,
      provisioned_by_discord_id
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
    ON CONFLICT (ticket_id) DO NOTHING;
    `,
    [
      customer.id,
      ticketId,
      mcSequence,
      `mc-${mcSequence}`,
      pteroUserId,
      serverName,
      mcSequence,
      metadata.planId || "mc_plan",
      planName,
      priceInr,
      priceUsd,
      ramMb,
      cpuPercent,
      storageGb * 1024,
      mcSequence,
      "10.0.3.1",
      port,
      member.user.id,
    ]
  );

  if (channel) {
    const embed = new EmbedBuilder()
      .setTitle("🎮 Minecraft Game Server Provisioned & Active!")
      .setColor(0x2ecc71)
      .setDescription(
        `Your **${planName}** Minecraft server is ready for play!\n\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `🎮 **SERVER DETAILS**\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `• **Server Name:** ${serverName}\n` +
          `• **Server IP Address:** \`minecraft.sharkbyte.com:${port}\`\n` +
          `• **Pterodactyl Panel:** [https://panel.sharkbyte.com](https://panel.sharkbyte.com)\n` +
          `• **Status:** 🟢 \`ACTIVE\`\n\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `⚙️ **ALLOCATED RESOURCES**\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `• **Memory:** ${ramGb} GB (${ramMb} MB)\n` +
          `• **CPU Limit:** ${cpuPercent}%\n` +
          `• **Storage:** ${storageGb} GB NVMe\n\n` +
          `🎮 *You can manage your server, upload plugins, and view console logs at the Pterodactyl panel!*`
      )
      .setFooter({ text: "Shark Byte • High Performance Minecraft Hosting" })
      .setTimestamp();

    await channel.send({ content: `${member}`, embeds: [embed] });
  }
}
